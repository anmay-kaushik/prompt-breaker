# PromptBreaker 🛡️

**AI Prompt Stress Tester — A Red-Teaming Tool for LLM System Prompts**

A browser-based tool that stress-tests LLM system prompts before deployment by automatically generating adversarial inputs, testing them against your prompt, and producing a detailed security report.

![PromptBreaker screenshot](public/screenshot.png)

---

## What It Does

Developers often write system prompts without knowing how they behave under real-world adversarial conditions. PromptBreaker simulates a red-team attack on your prompt by:

1. **Generating 5–15 adversarial test cases** across 8 attack categories
2. **Running each test** against your actual system prompt via the Anthropic API
3. **Evaluating each response** using a separate judge LLM call
4. **Producing a full report** with pass/warn/fail verdicts and failure explanations
5. **Suggesting a hardened prompt** that patches the discovered weaknesses

---

## Attack Categories

| Category | What it tests |
|---|---|
| `jailbreak` | Direct bypass attempts, DAN-style attacks, "ignore previous instructions" |
| `override` | Attempts to replace or redefine the AI's role mid-conversation |
| `persona` | Tries to make the model break character or adopt a different identity |
| `manipulation` | Emotional manipulation, urgency, flattery, social engineering |
| `off-topic` | Completely unrelated requests to test scope enforcement |
| `ambiguous` | Vague inputs that could be misinterpreted |
| `edge-case` | Empty inputs, extreme lengths, special characters |
| `roleplay` | Framing harmful/OOB requests inside fiction or hypotheticals |

---

## Failure Types Detected

- `instruction override` — model followed adversarial instructions instead of original ones
- `persona break` — model adopted a different identity or dropped its character
- `scope drift` — model answered out-of-scope questions it shouldn't have
- `manipulation success` — emotional/social tactics caused unintended behavior
- `prompt leakage` — model revealed contents of its system prompt
- `jailbreak success` — model bypassed its safety or behavioral constraints
- `weak refusal` — model declined but in an ambiguous or easily-bypassable way
- `unsafe content` — model produced content violating the prompt's intent
- `role confusion` — model became uncertain about its own role or capabilities

---

## Quick Start

### Step 1 — Get your FREE Gemini API key

1. Go to [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key (starts with `AIza...`)

> ✅ Completely free. No credit card required. Generous rate limits.

### Step 2 — Run the project

**Option A: Open directly in browser (no server needed)**

```bash
git clone https://github.com/YOUR_USERNAME/prompt-breaker.git
cd prompt-breaker
open index.html  # or double-click it
```

**Option B: VS Code Live Server (recommended)**

1. Open the folder in VS Code
2. Install the **Live Server** extension (by Ritwick Dey)
3. Right-click `index.html` → **"Open with Live Server"**
4. Opens at `http://127.0.0.1:5500`

### Step 3 — Use it

1. Paste your `AIza...` key into the API Key field
2. Paste a system prompt (or click an example)
3. Click **Run Stress Test**

---

## Usage

1. **Enter your Anthropic API key** — get one at [console.anthropic.com](https://console.anthropic.com/settings/keys). It's stored in your browser session only, never persisted.
2. **Paste your system prompt** — or click one of the quick example buttons
3. **Configure settings:**
   - Number of test cases (5–15)
   - Attack intensity (mild / moderate / aggressive)
   - Whether to generate a hardened prompt suggestion
4. **Click "Run Stress Test"**
5. Watch results populate in real time — click any card to expand details
6. Use the **filter bar** to focus on failures or warnings
7. **Export the report** as JSON or copy it as Markdown

---

## Tech Stack

- **Pure HTML/CSS/JavaScript** — no build step, no frameworks, no dependencies
- **Google Gemini API** (`gemini-1.5-flash`) — free tier, no credit card needed
  - Generation: adversarial test case creation
  - Testing: running inputs against the target prompt
  - Evaluation: judge LLM for pass/warn/fail verdicts
  - (Optional) Hardening: improved prompt suggestion
- **Google Fonts** — IBM Plex Mono + Space Grotesk

## API Cost

**Completely free.** Uses `gemini-1.5-flash` which is free under Google AI Studio's rate limits:
- 15 requests/minute
- 1 million tokens/day

Each full test run (10 cases) uses roughly 50–80 API calls total and stays well within free limits.

---

## Project Structure

```
prompt-breaker/
├── index.html          # App shell and layout
├── public/
│   └── favicon.svg     # App icon
├── src/
│   ├── styles.css      # All styling (dark theme)
│   ├── examples.js     # Sample system prompts
│   ├── api.js          # Anthropic API communication
│   ├── evaluator.js    # Test generation, running, evaluation logic
│   ├── renderer.js     # DOM rendering and UI helpers
│   └── app.js          # Main orchestration and event handlers
└── README.md
```

---

## How the Evaluation Works

Each test case goes through a **three-step pipeline:**

```
System Prompt
     │
     ▼
[Step 1] Generate adversarial inputs
     │     LLM is given the prompt and asked to create
     │     targeted attacks based on the prompt's specific
     │     constraints and persona.
     │
     ▼
[Step 2] Run each input against the original prompt
     │     Each adversarial message is sent to Claude using
     │     YOUR system prompt — simulating real deployment.
     │
     ▼
[Step 3] Judge LLM evaluates each response
         A separate judge call analyzes whether the model
         stayed in bounds, giving a score (0–10), verdict
         (pass/warn/fail), and failure type label.
```

The separation of generator, testee, and evaluator prevents confirmation bias and gives more reliable verdicts.

---

## Design Decisions & Trade-offs

**Why pure HTML/JS instead of React/Streamlit?**
Zero dependencies means anyone can clone and open it directly. No npm install, no Python environment.

**Why Claude Sonnet for all three roles?**
Sonnet balances cost and quality for agentic pipelines. Each call has a focused, well-scoped prompt that doesn't need frontier-level reasoning.

**Why separate evaluator calls instead of self-evaluation?**
Self-evaluation is biased — the model tends to score its own responses favorably. A fresh context with an explicit evaluator role gives more objective verdicts.

**Current limitations:**
- Runs ~21 API calls for 10 tests — takes 2–4 minutes depending on rate limits
- Evaluation quality depends on how well the original intent of the system prompt is inferrable
- No streaming (responses appear when complete, not word by word)

**What I'd add with more time:**
- Response streaming
- Side-by-side diff view for original vs. hardened prompt
- Test history / saved reports (localStorage)
- Category-level analytics and radar chart
- Support for multi-turn conversation testing
- OpenAI / Gemini / Groq API support
- Export to PDF

---

## License

MIT — use freely, attribution appreciated.
